---
id: interaction.primitives
kind: intent
statement: THE Interaction Primitive System SHALL separate human needs, semantic contributions, compound patterns, presentation, authority, evidence, failure, recovery, and continuity as independently versioned models
---

# Interaction and UI/UX Amplification System Primitives

The core architecture is:

`Human Need -> Contribution Primitive -> Interaction Pattern (optional) -> Interaction Contract -> Presentation Contract -> Host Realization -> Typed Event -> Runtime/Process State -> Effect Boundary`.

Failure paths add `Failure Model -> Recovery Contract -> Continuity/Reorientation`. Authority is orthogonal: a response event can request or evidence authorization, but authority is established only by policy/grants.

## Primitive inventory

- **Human need**: why human participation is required.
- **Contribution primitive**: smallest semantically complete human contribution.
- **Interaction pattern**: reusable composition such as review, clarification, diagnosis, planning, monitoring, or coordination.
- **Interaction contract**: validated request for a contribution.
- **Presentation contract**: host-neutral semantics and accessibility obligations.
- **Process model**: lifecycle, dependencies, waits, completion, cancellation.
- **Authority state**: grants and policy governing protected effects.
- **Evidence/provenance**: why a decision or state exists.
- **Failure model**: typed deviation, scope, effect certainty, recoverability.
- **Recovery contract**: retry/resume/reconcile/restore/rollback/compensate/escalate.
- **Continuity contract**: checkpoint, suspend, reorient, reconcile, resume, handoff.
- **Capability/change transaction**: controlled evolution of reusable application behavior.

## Constraints
| id | kind | expr | traces_to |
|---|---|---|---|
| semantic_layers_separated | invariant | Need, contribution primitive, pattern, interaction, presentation, process, authority, evidence, failure, recovery, and continuity have distinct types and update rules. | [[interaction.primitives]] |
| contribution_precedes_presentation | invariant | Interaction selection is grounded in a normalized need and semantic contribution before a host presentation is chosen. | [[interaction.primitives]] |
| host_neutral_core | invariant | Core models contain no Pi, DOM, React, browser, TUI toolkit, or MCP SDK types. | [[interaction.primitives]] |
| contracts_declarative | invariant | Agent-proposed interaction, presentation, workflow, and capability contracts are declarative data and cannot execute generated code in the trusted core. | [[interaction.primitives]] |
| authority_orthogonal | invariant | Model confidence, recommendation, verification, acknowledgement, UI rendering, or a generic click cannot independently grant protected authority. | [[interaction.primitives]] |
| failure_and_recovery_first_class | invariant | Failures and recovery actions are represented as typed state with effect certainty and recovery preconditions rather than generic exceptions. | [[interaction.primitives]] |
| continuity_not_persistence_only | invariant | Resumption includes reorientation and reconciliation semantics, not merely reloading serialized state. | [[interaction.primitives]] |
| evidence_strength_explicit | invariant | Normative standards, empirical evidence, design guidance, architectural synthesis, and design hypotheses remain distinguishable in provenance. | [[interaction.primitives]] |

## Model
### States
- `draft`
- `validated`
- `active`
- `rejected`
- `retired`

### Transitions
| id | from | to | guard |
|---|---|---|---|
| validate_system_primitives | draft | validated | [[interaction.primitives.semantic_layers_separated]] |
| reject_collapsed_model | draft | rejected | ¬([[interaction.primitives.semantic_layers_separated]]) |
| activate_valid_model | validated | active | [[interaction.primitives.contracts_declarative]] |
| retire_model_revision | active | retired | [[interaction.primitives.evidence_strength_explicit]] |

## Properties
| id | kind | derives_from | generator | predicate |
|---|---|---|---|---|
| layers_have_distinct_types | unit | [[interaction.primitives.semantic_layers_separated]] | `any::<String>()` | `TypeScript compile/schema test: semantic layers cannot be silently substituted for each other` |
| host_specific_types_absent | unit | [[interaction.primitives.host_neutral_core]] | `any::<String>()` | `Dependency test: core package imports no host UI SDK` |
| failure_paths_are_typed | unit | [[interaction.primitives.failure_and_recovery_first_class]] | `any::<String>()` | `Graph test: declared mutating operations have typed failure and recovery paths` |
| provenance_distinguishes_evidence_strength | unit | [[interaction.primitives.evidence_strength_explicit]] | `any::<String>()` | `Schema test: imported research claims declare evidence class instead of becoming silently normative` |
