# v2 Design Review and Change Rationale

## Decision

The previous corpus remains directionally valid, but its semantic center has changed from “interaction kinds” to a layered model:

**Need → Contribution Primitive → Interaction Pattern → Interaction Contract → Presentation**

This avoids mixing atomic human contributions with compound cognitive/workflow activities and UI controls.

## Research-supported changes adopted

1. Failure and recovery are normal runtime states.
2. Unknown external-effect outcome is distinct from failure.
3. Recovery operations require typed preconditions.
4. Continuity requires reorientation and reconciliation, not only persistence.
5. Accessibility obligations belong at the semantic contract boundary.
6. Adaptive interfaces require temporal stability and user control.
7. Machine conformance cannot establish empirical usability.

## Research recommendations deliberately not adopted verbatim

- **Blanket immediate human approval for every irreversible action:** rejected as a universal invariant. Explicit scoped delegated authority is required to support legitimate unattended automation.
- **Verification + authorization as one primitive:** split because correctness judgment and permission are different semantics.
- **Exactly nine primitives:** treated as useful evidence, not a closed ontology.
- **Mandatory quantile-dotplot uncertainty rendering:** not generalized across domains or TUI; uncertainty must be evidence-backed and semantically defined, while rendering remains host/domain appropriate.
- **Claims that tests already passed:** downgraded to planned acceptance criteria absent implementation evidence.

## Remaining open research questions

- Whether `acknowledge`, `defer`, and `cancel` are contribution primitives or universal control outcomes.
- Whether `allocate` deserves atomic status distinct from select + constrain.
- How much interaction-pattern structure should be standardized versus domain-defined.
- Empirical thresholds for interruption burden and adaptive-layout stability.
- Cross-host accessibility equivalence for low-bandwidth TUI environments.
