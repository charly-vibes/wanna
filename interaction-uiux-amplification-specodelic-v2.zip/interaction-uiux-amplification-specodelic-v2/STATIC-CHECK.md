# Static Corpus Check

- Spec files: **30**
- Constraint rows: **284**
- Property rows mapped to planned TypeScript tests: **242**
- Wiki references scanned: **700**
- Unresolved reference candidates: **0**
- Official Specodelic CLI: **NOT RUN**

This is a structural consistency check, not official Specodelic lint/model verification.
